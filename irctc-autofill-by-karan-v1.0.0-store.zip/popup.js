const $ = (id) => document.getElementById(id);
const FIELDS = ["userId", "password", "from", "to", "train", "cls", "quota", "bookAt", "mobile", "payment"];
const CHECKS = ["autoUpgrade", "confirmOnly"];
const AC = ["1A", "2A", "3A", "3E", "CC", "EC"];

// ---------- passengers ----------
function paxRow(p = {}) {
  const div = document.createElement("div");
  div.className = "pax";
  div.innerHTML = `
    <input class="n" placeholder="Rahul Sharma" value="">
    <input class="a" placeholder="28" maxlength="3" inputmode="numeric">
    <select class="g"><option value="M">M</option><option value="F">F</option><option value="T">T</option></select>
    <select class="b"><option value="">Koi bhi</option><option>LB</option><option>MB</option><option>UB</option><option>SL</option><option>SU</option></select>
    <select class="f"><option value="">—</option><option value="V">Veg</option><option value="N">Non-veg</option><option value="D">No food</option></select>
    <button class="del" title="Hatao">✕</button>`;
  div.querySelector(".n").value = p.name || "";
  div.querySelector(".a").value = p.age || "";
  div.querySelector(".g").value = p.gender || "M";
  div.querySelector(".b").value = p.berth || "";
  div.querySelector(".f").value = p.food || "";
  div.querySelector(".del").onclick = () => { div.remove(); updateCount(); };
  $("paxList").appendChild(div);
  updateCount();
}
function updateCount() {
  const n = $("paxList").children.length;
  $("paxCount").textContent = `(${n}/6)`;
  $("addPax").style.display = n >= 6 ? "none" : "";
}
function readPax() {
  return Array.from($("paxList").children).map((d) => ({
    name: d.querySelector(".n").value.trim(),
    age: d.querySelector(".a").value.trim(),
    gender: d.querySelector(".g").value,
    berth: d.querySelector(".b").value,
    food: d.querySelector(".f").value
  })).filter((p) => p.name);
}
// purane version ka text format bhi padh lo
function legacyPax(txt) {
  return (txt || "").split("\n").map((l) => l.trim()).filter(Boolean).map((l) => {
    const [name, age, gender, berth, food] = l.split(",").map((x) => (x || "").trim());
    return { name, age, gender: (gender || "M").toUpperCase(), berth: (berth || "").toUpperCase(), food: (food || "").toUpperCase() };
  });
}

// ---------- date: input type=date (YYYY-MM-DD) <-> IRCTC (DD/MM/YYYY) ----------
const isoToIrctc = (iso) => { const [y, m, d] = (iso || "").split("-"); return y ? `${d}/${m}/${y}` : ""; };
const irctcToIso = (s) => { const [d, m, y] = (s || "").split("/"); return y ? `${y}-${m}-${d}` : ""; };

// ---------- auto time ----------
function autoTime() {
  const q = $("quota").value;
  if (q === "TATKAL" || q === "PREMIUM TATKAL") $("bookAt").value = AC.includes($("cls").value) ? "10:00:00" : "11:00:00";
  else if (q === "GENERAL") $("bookAt").value = "";
}
$("cls").onchange = autoTime;
$("quota").onchange = autoTime;
document.querySelectorAll(".chip").forEach((c) => (c.onclick = () => ($("bookAt").value = c.dataset.t)));
$("swap").onclick = () => { const f = $("from").value; $("from").value = $("to").value; $("to").value = f; };
$("addPax").onclick = () => paxRow();

// ---------- read / validate ----------
function readForm() {
  const cfg = {};
  FIELDS.forEach((f) => (cfg[f] = $(f).value.trim()));
  CHECKS.forEach((f) => (cfg[f] = $(f).checked));
  cfg.from = cfg.from.toUpperCase();
  cfg.to = cfg.to.toUpperCase();
  cfg.date = isoToIrctc($("dateIso").value);
  if (cfg.bookAt && cfg.bookAt.length === 5) cfg.bookAt += ":00";
  cfg.passengers = readPax();
  return cfg;
}
function validate(c) {
  if (!c.userId || !c.password) return "User ID / Password bharo";
  if (!/^[A-Z]{2,5}$/.test(c.from) || !/^[A-Z]{2,5}$/.test(c.to)) return "From / To mein station CODE daalo (jaise DBG, NDLS)";
  if (c.from === c.to) return "From aur To same hain";
  if (!c.date) return "Journey date chuno";
  if (!/^\d{4,5}$/.test(c.train)) return "Train number 5 digit ka daalo";
  if (!c.passengers.length) return "Kam se kam ek passenger daalo";
  for (const p of c.passengers) if (!/^\d{1,3}$/.test(p.age)) return `${p.name} ki umar daalo`;
  if (c.mobile && !/^\d{10}$/.test(c.mobile)) return "Mobile 10 digit ka hona chahiye";
  return null;
}
function show(t, err) { $("msg").style.color = err ? "#b3261e" : "#1b8a3a"; $("msg").textContent = t; }

// ---------- load ----------
chrome.storage.local.get("cfg", ({ cfg }) => {
  cfg = cfg || {};
  FIELDS.forEach((f) => cfg[f] !== undefined && ($(f).value = cfg[f]));
  CHECKS.forEach((f) => cfg[f] !== undefined && ($(f).checked = cfg[f]));
  $("dateIso").value = irctcToIso(cfg.date);
  const pax = Array.isArray(cfg.passengers) ? cfg.passengers : legacyPax(cfg.passengers);
  (pax.length ? pax : [{}]).forEach(paxRow);
  if (!cfg.bookAt) autoTime();
});

// ---------- buttons ----------
$("save").onclick = () => {
  const cfg = readForm(), err = validate(cfg);
  if (err) return show(err, true);
  chrome.storage.local.set({ cfg }, () => show("Saved ✓"));
};
$("start").onclick = async () => {
  const cfg = readForm(), err = validate(cfg);
  if (err) return show(err, true);
  await chrome.storage.local.set({ cfg, run: { active: true, startedAt: Date.now() } });
  // IRCTC tab pehle se khula ho to wahi use karo, warna naya
  const tabs = await chrome.tabs.query({ url: "https://www.irctc.co.in/*" });
  if (tabs.length) {
    await chrome.tabs.update(tabs[0].id, { active: true, url: "https://www.irctc.co.in/nget/train-search" });
  } else {
    await chrome.tabs.create({ url: "https://www.irctc.co.in/nget/train-search" });
  }
  window.close();
};
$("stop").onclick = () => chrome.storage.local.set({ run: { active: false } }, () => show("Stopped"));
