/*
 * IRCTC Autofill by Karan — content script
 *
 * v1 se farq:
 *  - Har tick pe page pehchanta hai (login / search / train list / passenger / review / payment)
 *    aur jo page hai uska kaam karta hai. "Ek baar done" wale flags hata diye — error aaye to
 *    wahi step dobara chalega.
 *  - Login check ab "Welcome ..." / LOGOUT / MY ACCOUNT kisi se bhi hota hai.
 *  - Error popups (OK / Close) apne aap band karke retry.
 *  - Har 200ms check, taaki element aate hi action ho.
 *  - Review page: captcha type karke Enter dabate hi Continue.
 *
 * Captcha, OTP aur payment hamesha user khud karega.
 * Koi step atke to F12 -> Console mein "[QuickFill]" logs dekho, aur SEL update karo.
 */

const SEL = {
  userId: "input[formcontrolname='userid'], app-login input[placeholder='User Name'], input[placeholder='User Name']",
  password: "input[formcontrolname='password'], app-login input[type='password'], input[placeholder='Password']",
  loginCaptcha: "input#captcha, input[formcontrolname='captcha']",
  origin: "p-autocomplete[formcontrolname='origin'] input, #origin input",
  destination: "p-autocomplete[formcontrolname='destination'] input, #destination input",
  acItems: ".ui-autocomplete-panel li, .p-autocomplete-panel li, .ui-autocomplete-items li, .p-autocomplete-items li",
  date: "p-calendar[formcontrolname='journeyDate'] input, #jDate input",
  classDd: "p-dropdown[formcontrolname='journeyClass'], #journeyClass",
  quotaDd: "p-dropdown[formcontrolname='journeyQuota'], #journeyQuota",
  ddItems: "li[role='option'], .ui-dropdown-item, .p-dropdown-item",
  trainCard: "app-train-avl-enq",
  paxName: "p-autocomplete[formcontrolname='passengerName'] input, input[formcontrolname='passengerName'], input[placeholder='Passenger Name'], input[placeholder='Full Name as per Govt. ID']",
  paxAge: "input[formcontrolname='passengerAge'], input[placeholder='Age']",
  paxGender: "select[formcontrolname='passengerGender']",
  paxBerth: "select[formcontrolname='passengerBerthChoice']",
  paxFood: "select[formcontrolname='passengerFoodChoice']",
  mobile: "input#mobileNumber, input[formcontrolname='mobileNumber']",
  autoUpgrade: "p-checkbox[formcontrolname='autoUpgradationSelected'], p-checkbox[formcontrolname='autoUpgradation'], input#autoUpgradation",
  confirmOnly: "p-checkbox[formcontrolname='bookOnlyIfCnf'], p-checkbox[formcontrolname='bookOnlyIfConfirmBerths'], input#confirmberths",
  dialogs: "p-dialog .ui-dialog, p-confirmdialog .ui-dialog, .p-dialog, .ui-dialog, .p-toast-message, .ui-toast-message"
};

const CLASS_NAME = {
  SL: "SLEEPER (SL)", "3A": "AC 3 TIER (3A)", "3E": "AC 3 ECONOMY (3E)", "2A": "AC 2 TIER (2A)",
  "1A": "AC FIRST CLASS (1A)", CC: "AC CHAIR CAR (CC)", EC: "EXEC. CHAIR CAR (EC)", "2S": "SECOND SITTING (2S)"
};
const GENDER = { M: "Male", F: "Female", T: "Transgender" };
const BERTH = { LB: "Lower", MB: "Middle", UB: "Upper", SL: "Side Lower", SU: "Side Upper", NP: "No Preference" };
const FOOD = { V: "Veg", N: "Non Veg", D: "No Food" };

// ---------- helpers ----------
const log = (...a) => console.log("%c[QuickFill]", "color:#1b8a3a;font-weight:bold", ...a);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const q = (s, root = document) => root.querySelector(s);
const qa = (s, root = document) => Array.from(root.querySelectorAll(s));
const visible = (el) => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== "hidden";
const vq = (s, root) => qa(s, root).find(visible);
const norm = (t) => (t || "").replace(/\s+/g, " ").trim().toUpperCase();

async function waitFor(fn, timeout = 6000, every = 80) {
  const end = Date.now() + timeout;
  while (Date.now() < end) {
    const r = fn();
    if (r) return r;
    await sleep(every);
  }
  return null;
}

function setInput(el, value) {
  if (!el) return false;
  el.focus();
  const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto, "value").set.call(el, value);
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Unidentified" }));
  el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "Unidentified" }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}
const blur = (el) => el && (el.dispatchEvent(new Event("blur", { bubbles: true })), el.blur());

function setSelect(sel, text) {
  if (!sel || !text) return false;
  const want = norm(text);
  const opts = Array.from(sel.options);
  const opt = opts.find((o) => norm(o.text) === want) || opts.find((o) => norm(o.text).startsWith(want)) ||
              opts.find((o) => norm(o.text).includes(want));
  if (!opt) { log("select option nahi mila:", text); return false; }
  sel.value = opt.value;
  sel.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function clickEl(el) {
  if (!el) return false;
  el.scrollIntoView({ block: "center" });
  el.click();
  return true;
}

// exact text wala visible button (ya includes, agar exact na mile)
function findBtn(text, root = document) {
  const want = norm(text);
  const btns = qa("button, a.btn, input[type=submit]", root).filter(visible);
  return btns.find((b) => norm(b.textContent || b.value) === want) ||
         btns.find((b) => norm(b.textContent || b.value).includes(want));
}

function isLoggedIn() {
  const hdr = q("app-header") || document.body;
  const t = norm(hdr.innerText);
  return t.includes("WELCOME") || t.includes("LOGOUT") || t.includes("MY ACCOUNT");
}

function parsePassengers(src) {
  const up = (x) => (x || "").toString().trim().toUpperCase();
  const rows = Array.isArray(src) ? src
    : (src || "").split("\n").map((l) => l.trim()).filter(Boolean).map((l) => {
        const [name, age, gender, berth, food] = l.split(",").map((x) => (x || "").trim());
        return { name, age, gender, berth, food };
      });
  return rows.filter((r) => r && r.name).slice(0, 6).map((r) => ({
    name: r.name.trim(), age: String(r.age || "").trim(),
    gender: GENDER[up(r.gender)] || r.gender, berth: BERTH[up(r.berth)] || r.berth, food: FOOD[up(r.food)] || r.food
  }));
}

function targetTime(hhmmss) {
  if (!hhmmss) return 0;
  const [h, m, s = "0"] = hhmmss.split(":");
  const t = new Date(); t.setHours(+h, +m, +s, 0);
  return t.getTime();
}

// ---------- banner ----------
function banner(text, color = "#1b8a3a") {
  let b = document.getElementById("qf-banner");
  if (!b) {
    b = document.createElement("div");
    b.id = "qf-banner";
    b.style.cssText = "position:fixed;bottom:16px;left:16px;z-index:2147483647;color:#fff;" +
      "padding:10px 14px;border-radius:8px;font:600 14px system-ui;box-shadow:0 2px 10px #0005;max-width:420px";
    document.documentElement.appendChild(b);
  }
  b.style.background = color;
  b.textContent = "QuickFill: " + text;
}

// ---------- state ----------
let cfg = null, run = null, busy = false;
const cooldown = {};            // page -> timestamp jab tak dobara action nahi
const tries = {};               // page -> attempts
let holdUntil = 0;              // sab actions is time tak ruk jayenge
const coolFor = (k, ms) => (cooldown[k] = Date.now() + ms);
const cooling = (k) => (cooldown[k] || 0) > Date.now();

// ---------- error popups ----------
function handleDialogs() {
  for (const d of qa(SEL.dialogs).filter(visible)) {
    // login popup / form wale dialog ko kabhi band mat karo
    if (q("input:not([type=hidden]), select, textarea", d)) continue;
    const txt = norm(d.innerText);
    if (!txt || txt.length > 600) continue;
    // "request under process" = IRCTC kaam kar raha hai -> kuch mat dabao, bas ruko
    if (/UNDER PROCESS|DO NOT SUBMIT/.test(txt)) {
      banner("IRCTC process kar raha hai, ruko…", "#b36b00");
      holdUntil = Math.max(holdUntil, Date.now() + 6000);
      return "wait";
    }
    const yes = findBtn("YES", d) || findBtn("I AGREE", d);
    if (yes && /CONFIRM|AGREE|PROCEED|CONTINUE/.test(txt)) { log("confirm dialog -> yes"); clickEl(yes); return "confirm"; }
    const ok = findBtn("OK", d) || findBtn("CLOSE", d) || q(".ui-dialog-titlebar-close, .p-dialog-header-close, .ui-toast-close-icon, .p-toast-icon-close", d);
    if (ok && /ERROR|UNABLE|TRY AGAIN|FAILED|\bNOT\b|INVALID|SESSION|SORRY/.test(txt)) {
      log("error popup:", txt.slice(0, 160));
      banner("Error: " + txt.slice(0, 70) + " — 2s mein retry", "#b36b00");
      clickEl(ok);
      holdUntil = Date.now() + 2000;
      Object.keys(cooldown).forEach((k) => (cooldown[k] = Math.min(cooldown[k], Date.now() + 2000)));
      return "error";
    }
  }
  return null;
}

// ---------- stages ----------
function openLogin() {
  if (cooling("loginLink")) return;
  const isLoginTxt = (e) => /^LOGIN( \/ REGISTER)?$/.test(norm(e.textContent));
  const link = qa("a, button").filter(visible).find(isLoginTxt) || qa("span, div").filter(visible).find(isLoginTxt);
  if (link) { clickEl(link); banner("Login khol raha hoon…"); }
  coolFor("loginLink", 4000);
}

async function doLogin() {
  const uid = vq(SEL.userId);
  if (!uid) return openLogin();
  if (uid.value !== cfg.userId) setInput(uid, cfg.userId);
  const pw = vq(SEL.password);
  if (pw && pw.value !== cfg.password) setInput(pw, cfg.password);
  const cap = vq(SEL.loginCaptcha);
  if (cap) {
    if (!cap.value && !cooling("capFocus")) { cap.focus(); coolFor("capFocus", 3000); }
    // captcha likhna band karte hi (0.6s ruk ke) SIGN IN apne aap
    if (!cap.dataset.qf) {
      cap.dataset.qf = "1";
      let t = null;
      cap.addEventListener("input", () => {
        clearTimeout(t);
        t = setTimeout(() => {
          if (cap.value.trim().length >= 5 && document.contains(cap)) {
            const btn = findBtn("SIGN IN") || findBtn("LOGIN");
            if (btn) { clickEl(btn); banner("SIGN IN dabaya ✓"); }
          }
        }, 600);
      });
    }
  }
  banner("Sirf captcha likho — SIGN IN apne aap dabega");
}

async function pickDropdown(ddSel, wantTexts) {
  const dd = vq(ddSel);
  if (!dd) return false;
  const label = norm(dd.innerText);
  if (wantTexts.some((w) => label.includes(norm(w)))) return true;       // pehle se selected
  clickEl(q(".ui-dropdown, .p-dropdown", dd) || dd);
  const item = await waitFor(() => {
    const items = qa(SEL.ddItems).filter(visible);
    for (const w of wantTexts) {
      const W = norm(w);
      const hit = items.find((i) => norm(i.textContent) === W) || items.find((i) => norm(i.textContent).includes(W));
      if (hit) return hit;
    }
    return null;
  }, 3000);
  if (item) { clickEl(item); await sleep(80); return true; }
  log("dropdown option nahi mila:", wantTexts);
  document.body.click();
  return false;
}

// "NEW DELHI - NDLS" jaisa selected value hi valid hai; sirf "NDLS" type hua ho to nahi
const stationSelected = (input, code) => new RegExp("\\S.*-\\s*" + code + "$").test(norm(input.value));

async function typeLikeUser(input, text) {
  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
  input.focus();
  input.click();
  setter.call(input, "");
  input.dispatchEvent(new Event("input", { bubbles: true }));
  for (const ch of text) {
    input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: ch }));
    setter.call(input, input.value + ch);
    input.dispatchEvent(new InputEvent("input", { bubbles: true, data: ch, inputType: "insertText" }));
    input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: ch }));
    await sleep(8);
  }
}

async function fillStation(sel, code) {
  const input = vq(sel);
  if (!input) return false;
  if (stationSelected(input, code)) return true;
  // pichla koi suggestion panel khula ho to band
  document.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Escape" }));
  for (let attempt = 1; attempt <= 3; attempt++) {
    await typeLikeUser(input, code);
    const item = await waitFor(() => qa(SEL.acItems).filter(visible)
      .find((li) => new RegExp("-\\s*" + code + "\\b").test(norm(li.textContent))), 3000);
    if (item) {
      clickEl(item);
      await sleep(150);
      if (stationSelected(input, code)) return true;
    }
    log("station attempt", attempt, "fail:", code, "value=", input.value);
    await sleep(200);
  }
  return false;
}

async function doSearch() {
  if (cooling("search")) return;
  banner("Journey bhar raha hoon…");
  const okFrom = await fillStation(SEL.origin, cfg.from);
  const okTo = await fillStation(SEL.destination, cfg.to);

  const d = vq(SEL.date);
  if (d && d.value !== cfg.date) {
    setInput(d, cfg.date); blur(d);
    await sleep(80);
    document.body.click();           // calendar popup band
  }
  await pickDropdown(SEL.classDd, [CLASS_NAME[cfg.cls] || cfg.cls, "(" + cfg.cls + ")"]);
  await pickDropdown(SEL.quotaDd, [cfg.quota]);

  if (!okFrom || !okTo) {
    banner((okFrom ? "To" : "From") + " station dropdown se select nahi hua — list se khud chuno, baaki main karunga", "#b36b00");
    coolFor("search", 3000); return;
  }

  const btn = findBtn("SEARCH TRAINS") || findBtn("SEARCH");
  if (btn) { clickEl(btn); banner("Search kiya…"); }
  coolFor("search", 5000);            // agar page nahi badla to 5s baad dobara
}

async function doTrainList() {
  if (cooling("train")) return;
  const card = qa(SEL.trainCard).find((c) => new RegExp("\\(" + cfg.train + "\\)|\\b" + cfg.train + "\\b").test(c.textContent));
  if (!card) {
    banner("Train " + cfg.train + " list mein nahi dikhi — number/date check karo", "#b36b00");
    coolFor("train", 2000);
    return;
  }
  const CLS = "(" + cfg.cls.toUpperCase() + ")";
  // class tile (jaise "AC 3 Tier (3A)  Refresh")
  const clsTile = () => qa("div, td, strong, span", card).filter(visible)
    .filter((e) => norm(e.textContent).includes(CLS) && norm(e.textContent).length < 60)
    .sort((a, b) => a.textContent.length - b.textContent.length)[0];
  const tileBox = (t) => t && (t.closest(".pre-avl") || t.closest("td") || t.parentElement || t);
  // availability cell (jaise "Wed, 18 Nov  AVAILABLE-0010")
  const availCell = () => qa("div, td", card).filter(visible)
    .filter((e) => /AVAILABLE|AVL|WL|RAC|REGRET|NOT AVAILABLE/.test(norm(e.textContent)) &&
      /\d{1,2} [A-Z]{3}/.test(norm(e.textContent)) && norm(e.textContent).length < 60)
    .find((m, _, all) => !all.some((o) => o !== m && m.contains(o)));   // sabse andar wala box
  const bookBtn = () => qa("button", card).filter(visible)
    .find((b) => norm(b.textContent).includes("BOOK NOW"));
  const bookEnabled = (b) => b && !b.disabled && !b.classList.contains("disable-book") &&
    getComputedStyle(b).opacity > 0.8 && getComputedStyle(b).pointerEvents !== "none";

  // 1) class tile ek baar kholo (agar availability nahi dikh rahi)
  if (!availCell()) { clickEl(tileBox(clsTile())); await waitFor(availCell, 4000); }

  // 2) booking time tak ruko
  const t0 = targetTime(cfg.bookAt);
  if (t0 && Date.now() < t0 - 300) {
    card.scrollIntoView({ block: "center" });
    while (Date.now() < t0 && run && run.active) {
      banner(`⏳ ${cfg.bookAt} ka wait… (${Math.ceil((t0 - Date.now()) / 1000)}s) — login pehle se kar lo`);
      await sleep(Math.min(t0 - Date.now(), 200));
    }
    clickEl(tileBox(clsTile()));        // time hote hi fresh availability
    await sleep(300);
  }

  // 3) date cell select + Book Now; enable na ho to har 2s refresh
  banner("Availability select + Book Now…");
  let lastRefresh = Date.now();
  const end = Date.now() + 3 * 60 * 1000;
  while (Date.now() < end && run && run.active && document.contains(card)) {
    if (vq(SEL.userId)) return;                       // login popup aaya -> login stage
    const cell = availCell();
    if (cell && !cell.dataset.qfClicked) { clickEl(cell); cell.dataset.qfClicked = "1"; await sleep(150); }
    const b = bookBtn();
    if (bookEnabled(b)) {
      clickEl(b);
      banner("Book Now dabaya ✓");
      coolFor("train", 8000);                         // double click nahi
      await sleep(600);
      handleDialogs();
      return;
    }
    if (Date.now() - lastRefresh > 2000) {           // refresh sirf har 2s
      clickEl(tileBox(clsTile()));
      lastRefresh = Date.now();
      await waitFor(availCell, 3000);
    }
    await sleep(150);
  }
  banner("Book Now enable nahi hua — manually try karo", "#b3261e");
  coolFor("train", 5000);
}

// IRCTC ka "Please Wait..." loader dikh raha hai?
function isLoading() {
  if (qa("p-progressspinner, .ui-progress-spinner, .p-progress-spinner, .loading-bar, .my-loading").some(visible)) return true;
  // sirf chhota "Please Wait..." text (loader box), page ke kisi paragraph wala nahi
  return qa("div, span, p, strong, b, h3, h4, h5").some((e) => e.children.length === 0 &&
    /^PLEASE WAIT/.test(norm(e.textContent)) && norm(e.textContent).length < 25 && visible(e));
}

function fireClick(el) {
  if (!el) return;
  el.scrollIntoView({ block: "center" });
  for (const t of ["pointerdown", "mousedown", "pointerup", "mouseup"])
    el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window }));
  el.click();
}

function radioChecked(ctrl) {
  const input = ctrl.matches("input") ? ctrl : q("input[type=radio]", ctrl);
  const box = q("[role=radio], .ui-radiobutton-box, .p-radiobutton-box", ctrl);
  return !!((input && input.checked) || (box && (box.getAttribute("aria-checked") === "true" ||
    /ui-state-active|p-highlight/.test(box.className))));
}

// IRCTC: p-radiobutton[formcontrolname=paymentType]  id="2" = BHIM/UPI,  id="3" = Cards/Netbanking
async function selectPayment(mode) {
  const wantId = mode === "UPI" ? "2" : "3";
  const ctrls = qa("p-radiobutton[formcontrolname='paymentType'], p-radiobutton[formcontrolname='paymentMode'], input[type=radio][name='paymentType']");
  let ctrl = ctrls.find((c) => {
    const inp = c.matches("input") ? c : q("input[type=radio]", c);
    return c.id === wantId || (inp && inp.value === wantId) || c.getAttribute("inputid") === "paymentMode" + (mode === "UPI" ? "2" : "1");
  });
  if (!ctrl) {  // text se fallback — sirf apne label ka text dekho
    const re = mode === "UPI" ? /BHIM/ : /CREDIT/;
    ctrl = ctrls.find((c) => re.test(norm((q("label", c) || c).textContent)));
  }
  if (!ctrl) { log("payment radio nahi mila"); return false; }
  const root = ctrl.matches("input") ? (ctrl.closest("p-radiobutton") || ctrl) : ctrl;
  for (let k = 0; k < 3 && !radioChecked(root); k++) {
    fireClick(q("[role=radio], .ui-radiobutton-box, .p-radiobutton-box", root) || q("label", root) || root);
    await sleep(120);
  }
  const ok = radioChecked(root);
  log("payment", mode, ok ? "selected ✓" : "select FAIL");
  return ok;
}

async function doPassengers() {
  if (cooling("pax")) return;
  const pax = parsePassengers(cfg.passengers);
  banner("Passengers bhar raha hoon…");
  for (let i = 0; i < pax.length; i++) {
    let names = qa(SEL.paxName).filter(visible);
    if (names.length <= i) {
      const add = qa("a, span, button").filter(visible).find((e) => norm(e.textContent).includes("ADD PASSENGER"));
      if (add) clickEl(add);
      await waitFor(() => qa(SEL.paxName).filter(visible).length > i, 2500);
      names = qa(SEL.paxName).filter(visible);
    }
    const p = pax[i];
    if (names[i] && names[i].value !== p.name) { setInput(names[i], p.name); blur(names[i]); }
    const age = qa(SEL.paxAge).filter(visible)[i];
    if (age && age.value !== p.age) { setInput(age, p.age); blur(age); }
    setSelect(qa(SEL.paxGender).filter(visible)[i], p.gender);
    if (p.berth) setSelect(qa(SEL.paxBerth).filter(visible)[i], p.berth);
    if (p.food) setSelect(qa(SEL.paxFood).filter(visible)[i], p.food);
  }
  // name autocomplete popup band
  qa(SEL.acItems).filter(visible).length && document.body.click();

  const mob = vq(SEL.mobile);
  if (mob && cfg.mobile && mob.value !== cfg.mobile) { setInput(mob, cfg.mobile); blur(mob); }

  const setChk = (sel, v) => {
    const c = q(sel); if (!c) return;
    const inp = c.matches("input") ? c : q("input[type=checkbox]", c);
    const box = q(".ui-chkbox-box, .p-checkbox-box", c);
    const on = (inp && inp.checked) || (box && /ui-state-active|p-highlight/.test(box.className));
    if (!!on !== v) fireClick(box || c.closest("label") || c);
  };
  setChk(SEL.autoUpgrade, !!cfg.autoUpgrade);
  setChk(SEL.confirmOnly, !!cfg.confirmOnly);

  // payment option: BHIM/UPI ya Cards. Card wale label mein bhi "UPI_CC" likha hota hai,
  // isliye UPI ke liye "BHIM" se pehchano aur card ke liye "CREDIT".
  const payOk = await selectPayment(cfg.payment === "CARD" ? "CARD" : "UPI");
  if (!payOk) banner("Payment option khud chuno (BHIM/UPI)", "#b36b00");
  await sleep(200);

  if (isLoading()) { coolFor("pax", 1000); return; }
  const cont = findBtn("CONTINUE");
  if (cont) { clickEl(cont); banner("Continue dabaya ✓ — agla page aa raha hai…"); }
  else banner("Continue button nahi mila — khud dabao", "#b36b00");
  coolFor("pax", 25000);  // ek hi baar submit; 25s tak page na badle (aur loader na ho) tabhi dobara
}

function doReview() {
  const cap = vq(SEL.loginCaptcha);
  if (cap) {
    if (!cap.dataset.qf) {
      cap.dataset.qf = "1";
      cap.scrollIntoView({ block: "center" });
      cap.focus();
      cap.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && cap.value.trim().length >= 4) {
          e.preventDefault();
          const cont = findBtn("CONTINUE");
          if (cont) clickEl(cont);
        }
      });
    }
    banner("Captcha daalo aur Enter dabao → payment");
    return;
  }
  // captcha nahi hai -> seedha Continue (sirf ek baar, 12s cooldown)
  if (cooling("review")) return;
  const cont = findBtn("CONTINUE");
  if (cont) { clickEl(cont); banner("Review → Continue dabaya ✓"); }
  coolFor("review", 12000);
}

function stepText() {
  // upar ka stepper: 1 Passenger Details / 2 Review Journey / 3 Payment
  return norm((q("app-booking-stepper, .stepper, p-steps") || {}).innerText || "");
}

function pageName() {
  const p = location.pathname.toLowerCase();
  if (vq(SEL.userId)) return "login";                               // login popup sabse pehle
  if (p.includes("payment")) return "payment";
  if (vq(SEL.paxAge)) return "pax";
  if (p.includes("review") || q("app-review-booking") ||
      (findBtn("CONTINUE") && /REVIEW JOURNEY/.test(norm(document.body.innerText.slice(0, 3000))) && !vq(SEL.paxAge))) return "review";
  if (!isLoggedIn()) return "needLogin";                             // pehle login, fir baaki
  if (p.includes("train-list") || q(SEL.trainCard)) return "train";
  if (vq(SEL.origin)) return "search";
  return "other";
}

// ---- extension reload/update ke baad purana script chupchaap band ho jaye ----
let timer = null;
const alive = () => { try { return !!chrome.runtime && !!chrome.runtime.id; } catch (e) { return false; } };
function shutdown() {
  if (timer) clearInterval(timer);
  timer = null;
  const b = document.getElementById("qf-banner");
  if (b) { b.style.background = "#555"; b.textContent = "QuickFill: extension reload hua — ye tab refresh karo (F5)"; }
}
async function save(obj) {
  if (!alive()) return shutdown();
  try { await chrome.storage.local.set(obj); } catch (e) { shutdown(); }
}

async function tick() {
  if (busy) return;
  if (!alive()) return shutdown();
  if (!cfg || !run || !run.active) return;
  busy = true;
  try {
    if (Date.now() - run.startedAt > 45 * 60 * 1000) { run.active = false; await save({ run }); return; }
    { const d = handleDialogs(); if (d === "error" || d === "wait") return; }
    if (Date.now() < holdUntil) return;
    if (isLoading()) { banner("IRCTC load ho raha hai (Please Wait)…"); return; }

    const page = pageName();
    tries[page] = (tries[page] || 0) + 1;
    switch (page) {
      case "login": await doLogin(); break;
      case "needLogin": openLogin(); break;
      case "search": await doSearch(); break;
      case "train": await doTrainList(); break;
      case "pax": await doPassengers(); break;
      case "review": doReview(); break;
      case "payment":
        banner("Payment page — ab payment khud karo ✓");
        run.active = false; await save({ run });
        break;
    }
  } catch (e) {
    if (/context invalidated/i.test(e && e.message)) return shutdown();
    log("error:", e);
    banner("Script error, retry… (" + e.message + ")", "#b36b00");
  } finally {
    busy = false;
  }
}

// config memory mein rakho; storage har tick pe nahi padhna (tez)
chrome.storage.local.get(["cfg", "run"]).then((st) => { cfg = st.cfg; run = st.run; }).catch(shutdown);
chrome.storage.onChanged.addListener((ch) => {
  if (ch.cfg) cfg = ch.cfg.newValue;
  if (ch.run) {
    run = ch.run.newValue;
    if (run && !run.active) {
      const b = document.getElementById("qf-banner");
      if (b && !/PAYMENT/i.test(b.textContent)) b.remove();
    }
  }
});

log("v6 loaded on", location.pathname);
timer = setInterval(tick, 100);
