# Privacy Policy — IRCTC Autofill by Karan

Last updated: 19 September 2026

IRCTC Autofill by Karan ("the extension") helps users fill their own booking forms on www.irctc.co.in faster.

## What data the extension handles
The user types these details into the extension popup:
- IRCTC user ID and password
- Journey details (stations, date, train number, class, quota)
- Passenger details (name, age, gender, berth and food preference)
- Mobile number and preferred payment mode

## Where the data is stored
- All data is stored **only on the user's own computer**, in Chrome's local extension storage (`chrome.storage.local`).
- The extension has **no server**. No data is sent to the developer or to any third party.
- The data is used only to fill forms on www.irctc.co.in, in the user's own browser tab.

## What the extension does NOT do
- It does not collect, sell or share any personal data.
- It does not use analytics or tracking.
- It does not read or store payment card, UPI or bank details.
- It does not solve or bypass CAPTCHA or OTP. The user completes CAPTCHA, OTP and payment themselves.

## Deleting your data
Clear the fields in the popup and click Save, or remove the extension from `chrome://extensions`. Removing the extension deletes all of its stored data.

## Disclaimer
This extension is an independent tool. It is **not affiliated with, endorsed by or connected to IRCTC or Indian Railways**. Use it only for your own bookings and in line with IRCTC's terms of use.

## Contact
Karan Gupta — <add your support email here>
