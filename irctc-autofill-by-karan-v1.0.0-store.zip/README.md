# IRCTC Autofill by Karan

A Chrome extension that fills IRCTC booking forms quickly: login ID/password, journey, passengers and payment option.
**CAPTCHA, OTP and payment are always done by the user.**

> Not affiliated with IRCTC or Indian Railways. Use only for your own bookings.

## Install (without Chrome Web Store)
1. Download the zip from the [Releases](../../releases) page and extract it.
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and select the extracted folder.
5. Pin the extension from the puzzle icon.

## How to use
1. Open the extension, enter your ID, journey and passengers, then click **Save**.
2. 5–7 minutes before the booking window opens, click **Start ▶**.
3. IRCTC opens and the login popup is filled. **Type the captcha**, and SIGN IN is pressed automatically.
4. Search, train selection and Book Now happen automatically at the time you set (AC 10:00 / Non-AC 11:00).
5. Passengers and the BHIM/UPI option are filled, then Continue is pressed.
6. Complete the payment yourself.

## Tips
- Keep your computer clock correct (Settings → Time → Sync now).
- After updating or reloading the extension, refresh the IRCTC tab (F5).
- Tatkal booking needs an Aadhaar-verified IRCTC account.
- Do not save your password on a shared computer.

## Privacy
All data stays on your computer. See [PRIVACY.md](PRIVACY.md).
